import HeaderMenu from './menu-header.js'
import FooterMenu from './menu-footer.js'
import SidebarMenu from './menu-sidebar.js'

export default {
    HeaderMenu,
    FooterMenu,
    SidebarMenu
}